var struct__SHA256__CTX =
[
    [ "bitcount", "struct__SHA256__CTX.html#ae03d7f91de6eb6cb110d3d054e58d935", null ],
    [ "buffer", "struct__SHA256__CTX.html#ae1c9099b16619b706dbc88203ce3c189", null ],
    [ "state", "struct__SHA256__CTX.html#a0735cc1e8e2d7e0f2fc54cec5c05b1d3", null ]
];