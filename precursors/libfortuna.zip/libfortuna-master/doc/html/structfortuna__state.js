var structfortuna__state =
[
    [ "ciph", "structfortuna__state.html#a95ce19ebcf8f4b5194747800cda1c30c", null ],
    [ "counter", "structfortuna__state.html#a98c15b091e0c6406775caf43044234ae", null ],
    [ "key", "structfortuna__state.html#ab0661b7a7c12092dc667af5cdbd8d9cf", null ],
    [ "last_reseed_time", "structfortuna__state.html#a6d4e1a0a714f4826e1ac2568ef39362c", null ],
    [ "pool", "structfortuna__state.html#a53d7ea36f61adaa577f1328071abc3e8", null ],
    [ "pool0_bytes", "structfortuna__state.html#aaf71b2ed6c86a11f8abbe5ee3277c4a5", null ],
    [ "reseed_count", "structfortuna__state.html#aa8237da33b2f2838320097ed06837879", null ],
    [ "result", "structfortuna__state.html#a6331223fd25966c963e9cc2b6051d8ae", null ],
    [ "rnd_pos", "structfortuna__state.html#a6b390be97975dff29c08c06ecf1bdb3a", null ],
    [ "tricks_done", "structfortuna__state.html#a4ea7c5da5396b8f797f36993a98de5fe", null ]
];