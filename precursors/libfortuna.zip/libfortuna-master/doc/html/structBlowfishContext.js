var structBlowfishContext =
[
    [ "iv0", "structBlowfishContext.html#aa80f8ad06bdd18fef0be9554f2ea5510", null ],
    [ "iv1", "structBlowfishContext.html#a518bdae94e7c2c78e1df8360613c6169", null ],
    [ "P", "structBlowfishContext.html#a5d05589f7d074010916fb2988e8bd473", null ],
    [ "S0", "structBlowfishContext.html#a736b98792c3562062d6d95f10f200437", null ],
    [ "S1", "structBlowfishContext.html#a2055ed05016aa2deae873afceae591e6", null ],
    [ "S2", "structBlowfishContext.html#ad8104967f5b964f5c0c2f10443c1b2aa", null ],
    [ "S3", "structBlowfishContext.html#a82698e87c73d32dcd253a558f3ebb685", null ]
];