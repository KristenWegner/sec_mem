var random_8c =
[
    [ "RND_BYTES", "random_8c.html#a4cf5f8f5bd7745ddb1b8fda81d935d9d", null ],
    [ "TRY_DEV_RANDOM", "random_8c.html#aa1d5519d1bb712ae3ebd235981822ff5", null ],
    [ "px_acquire_system_randomness", "random_8c.html#aa082dfc0d80af51bac9708935588acaf", null ],
    [ "safe_read", "random_8c.html#a1a8adb27bafb42be2b2fced8257312e1", null ],
    [ "try_dev_random", "random_8c.html#a5fbf11f9797d5a254fe556f35e0069b0", null ]
];