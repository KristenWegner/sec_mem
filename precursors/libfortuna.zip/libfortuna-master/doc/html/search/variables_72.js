var searchData=
[
  ['reseed_5fcount',['reseed_count',['../structfortuna__state.html#aa8237da33b2f2838320097ed06837879',1,'fortuna_state']]],
  ['reset',['reset',['../structpx__digest.html#a72f538447abc9a94dd7d9ef52ae6327a',1,'px_digest::reset()'],['../structpx__hmac.html#a64ffc8c49352689a88434c0ebc037714',1,'px_hmac::reset()']]],
  ['result',['result',['../structfortuna__state.html#a6331223fd25966c963e9cc2b6051d8ae',1,'fortuna_state']]],
  ['result_5fsize',['result_size',['../structpx__digest.html#a02a702a5d459e7f985658d9c217112c4',1,'px_digest::result_size()'],['../structpx__hmac.html#a0cb0b623751c051d891c014c9205d580',1,'px_hmac::result_size()']]],
  ['rj',['rj',['../structint__ctx.html#ae6455e9eaa34ec09871fa52ec7becb77',1,'int_ctx']]],
  ['rnd_5fpos',['rnd_pos',['../structfortuna__state.html#a6b390be97975dff29c08c06ecf1bdb3a',1,'fortuna_state']]]
];
