var searchData=
[
  ['num_5fpools',['NUM_POOLS',['../fortuna_8c.html#a2c5a4c46ba326a907d016cc28654e39e',1,'fortuna.c']]]
];
