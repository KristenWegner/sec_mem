var searchData=
[
  ['fortuna_5fadd_5fentropy',['fortuna_add_entropy',['../fortuna_8c.html#a704f564a22ded8759c8ba80938b44c8b',1,'fortuna_add_entropy(const uint8 *data, unsigned len):&#160;fortuna.c'],['../fortuna_8h.html#a704f564a22ded8759c8ba80938b44c8b',1,'fortuna_add_entropy(const uint8 *data, unsigned len):&#160;fortuna.c']]],
  ['fortuna_5fget_5fbytes',['fortuna_get_bytes',['../fortuna_8c.html#aa118831145998f761723ee27f8aff541',1,'fortuna_get_bytes(unsigned len, uint8 *dst):&#160;fortuna.c'],['../fortuna_8h.html#aa118831145998f761723ee27f8aff541',1,'fortuna_get_bytes(unsigned len, uint8 *dst):&#160;fortuna.c']]]
];
