var searchData=
[
  ['fortuna_5fstate',['fortuna_state',['../structfortuna__state.html',1,'']]]
];
