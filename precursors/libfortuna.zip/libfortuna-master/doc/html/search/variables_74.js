var searchData=
[
  ['tricks_5fdone',['tricks_done',['../structfortuna__state.html#a4ea7c5da5396b8f797f36993a98de5fe',1,'fortuna_state']]]
];
