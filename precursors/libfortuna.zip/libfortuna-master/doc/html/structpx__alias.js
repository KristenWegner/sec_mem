var structpx__alias =
[
    [ "alias", "structpx__alias.html#a6f18118842e0ee16f4090235a871de49", null ],
    [ "name", "structpx__alias.html#a92b52c073139e7dac0fc7b45478f7702", null ]
];