var annotated =
[
    [ "_rijndael_ctx", "struct__rijndael__ctx.html", "struct__rijndael__ctx" ],
    [ "_SHA256_CTX", "struct__SHA256__CTX.html", "struct__SHA256__CTX" ],
    [ "_SHA512_CTX", "struct__SHA512__CTX.html", "struct__SHA512__CTX" ],
    [ "BlowfishContext", "structBlowfishContext.html", "structBlowfishContext" ],
    [ "error_desc", "structerror__desc.html", "structerror__desc" ],
    [ "fortuna_state", "structfortuna__state.html", "structfortuna__state" ],
    [ "int_cipher", "structint__cipher.html", "structint__cipher" ],
    [ "int_ctx", "structint__ctx.html", "structint__ctx" ],
    [ "int_digest", "structint__digest.html", "structint__digest" ],
    [ "md5_ctxt", "structmd5__ctxt.html", "structmd5__ctxt" ],
    [ "px_alias", "structpx__alias.html", "structpx__alias" ],
    [ "px_cipher", "structpx__cipher.html", "structpx__cipher" ],
    [ "px_combo", "structpx__combo.html", "structpx__combo" ],
    [ "px_digest", "structpx__digest.html", "structpx__digest" ],
    [ "px_hmac", "structpx__hmac.html", "structpx__hmac" ],
    [ "sha1_ctxt", "structsha1__ctxt.html", "structsha1__ctxt" ]
];