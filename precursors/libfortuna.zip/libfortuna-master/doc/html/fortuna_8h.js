var fortuna_8h =
[
    [ "fortuna_add_entropy", "fortuna_8h.html#a704f564a22ded8759c8ba80938b44c8b", null ],
    [ "fortuna_get_bytes", "fortuna_8h.html#aa118831145998f761723ee27f8aff541", null ]
];