var structerror__desc =
[
    [ "desc", "structerror__desc.html#a8bd78a0b6c726e6cf5a8d30c9fead5e3", null ],
    [ "err", "structerror__desc.html#a8cae12d5e24f7bda4bb2f3da5124a17c", null ]
];