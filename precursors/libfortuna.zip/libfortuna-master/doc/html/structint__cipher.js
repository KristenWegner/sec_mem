var structint__cipher =
[
    [ "load", "structint__cipher.html#a30235bc76f5f13c478cb48db07fffe6e", null ],
    [ "name", "structint__cipher.html#a4964144dbab1ea02b5ffe63335c0c3c1", null ]
];