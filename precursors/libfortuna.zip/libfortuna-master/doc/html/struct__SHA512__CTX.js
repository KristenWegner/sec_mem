var struct__SHA512__CTX =
[
    [ "bitcount", "struct__SHA512__CTX.html#a65507242047a042c46547894790a07ed", null ],
    [ "buffer", "struct__SHA512__CTX.html#af5939aad9b5e75338c05523479208e5f", null ],
    [ "state", "struct__SHA512__CTX.html#aa31ef0b0038ff139062dd31a17110043", null ]
];