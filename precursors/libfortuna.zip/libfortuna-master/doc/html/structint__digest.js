var structint__digest =
[
    [ "init", "structint__digest.html#a44eb65485145dd35a5cd127439b52e18", null ],
    [ "name", "structint__digest.html#a174f99c47920240e2e424f34c5d7f0f7", null ]
];