var structint__ctx =
[
    [ "bf", "structint__ctx.html#aac34653068b3f2179215d2d5cd2ace10", null ],
    [ "ctx", "structint__ctx.html#a752ea1cbe27058721c7f31696dd440f2", null ],
    [ "is_init", "structint__ctx.html#a1ec0a9b4938c69f8c3dda43f2df27367", null ],
    [ "iv", "structint__ctx.html#ae931dacd2536e5b4ef71871e351cc6da", null ],
    [ "keybuf", "structint__ctx.html#a896ecf3eb20dd99e750c356fc44825e2", null ],
    [ "keylen", "structint__ctx.html#aa09fedf5414ec886700046bb5b52e9ec", null ],
    [ "mode", "structint__ctx.html#a02e9a0634da59d3a196f14dcaed77df7", null ],
    [ "rj", "structint__ctx.html#ae6455e9eaa34ec09871fa52ec7becb77", null ]
];