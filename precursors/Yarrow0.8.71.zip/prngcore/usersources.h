/* usersources.h */
/* This files contain the defination of the user supplied entropy sources */

#ifndef YARROW_USER_SOURCES_H
#define YARROW_USER_SOURCES_H

enum user_sources {
	USERSOURCE1 = 0,
	USERSOURCE2,
	USERSOURCE3,
	USER_SOURCES  /* Leave as last source */
};

#endif